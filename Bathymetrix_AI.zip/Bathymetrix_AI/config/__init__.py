# Init for config
